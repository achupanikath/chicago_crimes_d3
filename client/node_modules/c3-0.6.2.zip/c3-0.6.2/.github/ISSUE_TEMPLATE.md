<!--

This is not a catch-all support forum, for general support enquiries, please use the Google Group at https://groups.google.com/forum/#!forum/c3js.
 
Thank you for reporting an issue.

Please fill in as much of the template below as you're able.

C3 version: The c3 version number which is available from `c3.version`.
D3 version: The d3 version number.
Browser: The browser version.
OS: The operating system.

If possible, please provide codepen or jsfiddle example that demonstrates the problem, keeping it as
simple and free of external dependencies as you are able.
-->

* **C3 version**:
* **D3 version**:
* **Browser**:
* **OS**:
